<?php
    get_header();
?>

<?php if(have_posts() ) : while(have_posts()):the_post(); 
    // Boucle php qui permet d'interroger la BDD et s'il y a des choses à afficher de le faire "posts correspond à article ou page"
?>


<h2 class="titrepost"><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>

<div class="entry">

    <?php the_content();?>

</div>

<?php endwhile; else : ?>
    <p>Contenu introuvable</p>
<?php endif; ?>

<?php get_footer(); ?>



