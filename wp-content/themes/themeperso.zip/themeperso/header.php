<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">

    <!-- CSS BOOTSTRAP -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <!-- CSS
    bloginfo() est un lien hypertext 
    exemple : href="http://localhost/wpdev/wp-content/themes/themeperso/style.css"> 
    -->
    <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css">

    <!--  FONTS -->
    <link rel="preconnect" href="http://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Xanh+Mono:ital@1&display=swap" rel="stylesheet">


    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- On va synchroniser le titre du thème avec le Back Office donc la BDD  -->
    <title><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <!-- HEADER -->
    <div class="container-fluid">

        <!-- ENTETE -->
        <div class="row">


            <div class="col-md-3 haut-gauche">
                <?php dynamic_sidebar('haut-gauche'); ?>
            
            
            </div>

            <div class="col-md-6 haut-centre">
                <?php dynamic_sidebar('haut-centre'); ?>

            
            </div>

            <div class="col-md-3 haut-droite">
                <?php dynamic_sidebar('haut-droite'); ?>

            
            </div>
        
        
        </div>

        <!-- BANNER -->
        <div class="row">

            <div class="col-md-12 entete">
                <?php dynamic_sidebar('entete'); ?>

            </div>
        
        </div>

        <!-- NAV PRIMARY -->

        <div class="row">
        
            <div class="col-md-12 menuheader">
                <?php wp_nav_menu(array('container_class' => 'menuheader', 'theme_location' => 'primary')); ?>
            
            </div>
        
        </div>
    
    </div>


    <!-- BODY -->
    <div class="container-fluid">
    
        <section>
        

    
