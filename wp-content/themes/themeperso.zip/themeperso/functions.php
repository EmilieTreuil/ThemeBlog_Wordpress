<?php

add_action('widgets_init', 'themeperso_init_sidebar');
// Ici on crée un hook qui permet d'accrocher les widgets à notre thème

add_action('init', 'themeperso_init_menu');

function themeperso_init_sidebar() {

    // register_sidebar
    register_sidebar(array(
        'name' => __('haut_gauche', 'themeperso'),
        'id' => 'haut-gauche',
        'description' => __('region en haut à gauche', 'themeperso')
    ));

    register_sidebar(array(
        'name' => __('haut_centre', 'themeperso'),
        'id' => 'haut-centre',
        'description' => __('region en haut au centre', 'themeperso')
    ));

    register_sidebar(array(
        'name' => __('haut_droite', 'themeperso'),
        'id' => 'haut-droite',
        'description' => __('region en haut à droite', 'themeperso')
    ));

    register_sidebar(array(
        'name' => __('entete', 'themeperso'),
        'id' => 'entete',
        'description' => __('region entete', 'themeperso')
    ));

    register_sidebar(array(
        'name' => __('bas-gauche', 'themeperso'),
        'id' => 'bas-gauche',
        'description' => __('region en bas à gauche', 'themeperso')
    ));

    register_sidebar(array(
        'name' => __('bas-droite', 'themeperso'),
        'id' => 'bas-droite',
        'description' => __('region en bas à droite', 'themeperso')
    ));

    

}


function themeperso_init_menu()
{
    register_nav_menu('primary',__('Primary Menu','themeperso'));
}

?>